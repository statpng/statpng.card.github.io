btob <- function(x, name) paste0( deparse(substitute(name)),"=",x[1],"to",x[length(x)] )


make.pf <- function(Y, idx){
  Y <- Data$y
  n.remained <- NCOL(Y[,-idx])
  PF <- c( rep( 0, n.remained ), rep( 1, ncol(x) ) )
  return(PF)
}



sp.glmnet <- function(x, y, psub=0.5, K=100, seq.alpha=NULL, n.lambda=NULL, family="gaussian", ...){
  if( NROW(y) != nrow(x) ) stop("x and y should be equal length of row")
  if( NCOL(y)>1 & (family!="mgaussian") ) stop("The family should be 'mgaussian'")
  if( NCOL(y)==1 & (family=="mgaussian") ) stop("The family should not be 'mgaussian'")
  
  if(is.null(seq.alpha)) seq.alpha <- 1:9*0.1
  if(is.null(n.lambda)) n.lambda <- 10
  
  x <- as.matrix(x)
  y <- as.matrix(y)
  
  n <- nrow(x);
  p <- ncol(x);
  nsub <- n*psub;
  
  vector.lambda <- NULL
  
  for( j in 1:length(seq.alpha) ){
    for( i in 1:10 ){
      wsub <- sample(n, nsub)
      xsub <- x[wsub,]
      ysub <- y[wsub,]
      fitsub <- glmnet(x=xsub, y=ysub, alpha=seq.alpha[j], family=family, ... )
      vector.lambda <- c( vector.lambda, fitsub$lambda )
    }
  }
  
  lambda.min <- min(vector.lambda)
  lambda.max <- max(vector.lambda)
  seq.lambda <- seq(lambda.min, lambda.max, length.out=n.lambda);
  
  ncol.y <- length( append(fitsub$beta, NULL) )
  
  OUT <- as.list(seq_len(ncol.y));
  for( h in seq_len(ncol.y) ){
    out <- array(0, c(ncol(x), length(seq.lambda), length(seq.alpha)) );
    for( j in 1:length(seq.alpha) ){
      for( i in 1:K ){
        wsub <- sample(n, nsub);
        xsub <- x[wsub,];
        ysub <- y[wsub,];
        glmnet.fit <- glmnet(x=xsub, y=ysub, alpha=seq.alpha[j], lambda=seq.lambda, family=family, ... )
        out[,,j] <- out[,,j] + as.numeric( append( NULL, glmnet.fit$beta )[[h]]!=0 ) ;
      }
    }
    OUT[[h]] <- out
  }
  if( length(OUT)==1 ) OUT <- do.call(as.array, OUT)
  
  return(OUT);
}




tpr.top <- function(sp, top, true){
    sp.sort <- sort( sp, decreasing=TRUE )
    thr <- sp.sort[top]
    sg <- sum( which(sp>thr) %in% true )
    ng <- length( which(sp>thr) )
    se <- sum( which(sp==thr) %in% true)
    ne <- length( which(sp==thr) )
    (sg+se*(top-ng)/ne)/length(true)
}


print.sp <- function(out.sp, true, top=80, alpha=TRUE, lambda=TRUE, K=K){
    
    sp <- apply( out.sp[,lambda,alpha,drop=FALSE], 1, max )/K
    list(
        TPR = tpr.top(sp, top, true),
        sp.top = data.frame(order=order( sp, decreasing=TRUE), 
                            sp=sort( sp, decreasing=TRUE))[1:top, ],
        nonzero = out.sp[order( sp, decreasing=TRUE )[1:top],lambda,alpha] ,
        true = out.sp[true,lambda,alpha]
    )
}


