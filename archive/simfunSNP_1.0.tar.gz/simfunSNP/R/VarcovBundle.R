SampleSign <- function(Matrix, PropOfNeg=PropOfNeg){
  Matrix[ lower.tri(Matrix) ] <- sapply( Matrix[ lower.tri(Matrix) ], function(x) (-1)^rbinom(1,1,PropOfNeg)*x )
  Matrix[ upper.tri(Matrix) ] <- t(Matrix)[ upper.tri(Matrix) ]
  Matrix
}
digits <- function(x, which=1e1){
  as.numeric( unlist(strsplit(as.character(x),""))[nchar(x)+1-log10(10*which)] )
}

Varcov_rho <- function(p, rho){
  out <- matrix(rho, p, p)
  diag(out) <- 1
  return(out)
}

GenVarcov <- function(m, Omega = 0, PropOfNeg = 0.25, rho=0){
  if( PropOfNeg<0 | PropOfNeg>0.5 ) stop("PropOfNeg must be in [0,0.5].");
  
  if( rho == 0 ){
  e.rho <- replicate( m*(m-1)/2, runif(1,0,1) )
  e.varcov <- matrix(1, m, m)
  e.varcov[upper.tri(e.varcov)] <- e.rho
  e.varcov[lower.tri(e.varcov)] <- t(e.varcov)[lower.tri(e.varcov)]
  e.varcov <- SampleSign(e.varcov, PropOfNeg = PropOfNeg)
  isSymmetric(e.varcov)
  
  x <- (e.varcov %*% e.varcov) + diag(Omega, m)
  e.varcov2 <- (x/sqrt(diag(x)%*%t( diag(x) )))
  
  } else if ( rho>0 ) {
    e.varcov2 <- Varcov_rho(p=m, rho=rho)
  }
  
  # e.varcov2 %>% .[upper.tri(.)] %>% hist(main="Error-term correlation", xlab=expression(rho,"e"))
  
  invisible(e.varcov2)
}