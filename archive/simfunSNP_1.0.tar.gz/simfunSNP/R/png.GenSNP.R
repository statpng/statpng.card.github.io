png.GenSNP <- function(n, p, rho, threads=threads, display_progress=FALSE ){
  
  X <- do.call("cbind", lapply( 1:20, function(x) mnormt::rmnorm( n, varcov=ARCOV_C(p=(p/20), rho=rho, threads=1, display_progress=display_progress) ) ) )
  Y <- do.call("cbind", lapply( 1:20, function(x) mnormt::rmnorm( n, varcov=ARCOV_C(p=(p/20), rho=rho, threads=1, display_progress=display_progress) ) ) )
  
  MAF <- truncnorm::rtruncnorm(p, a=-0.65, b=0.65, mean=0, sd=5)^2
  
  for(j in seq_len(p)){
    
    perct_X <- rank( (X[,j]) )/length(X[,j])
    perct_Y <- rank( (Y[,j]) )/length(Y[,j])
    
    X[perct_X <= MAF[j], j] <- 1
    X[perct_X >  MAF[j], j] <- 0
    Y[perct_Y <= MAF[j], j] <- 1
    Y[perct_Y >  MAF[j], j] <- 0
    
  }
  
  Data <- rbind( X + Y )
  
  return(list(snp=Data, MAF=MAF));
}