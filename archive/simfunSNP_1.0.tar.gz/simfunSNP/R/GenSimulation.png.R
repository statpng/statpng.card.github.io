GenSimulation.png <- function(n, p, M=25, snp.rho=0.6, ptrue=c(0.001, 0.005, 0.01), Beta=1, Beta.pdec=0.1, pcross=0.2,
                              y.pNeg=0.2, Omega=0, rho=0.3){
  
  # snp <- do.call( "cbind", lapply(MAF, function(x) rbinom(n, 2, x) ) )
  GenSNP <- png.GenSNP(n=n, p=p, rho=snp.rho)
  snp <- GenSNP$snp
  MAF <- GenSNP$MAF
  dimnames(snp) <- list(paste0("N",1:n), paste0("snp", 1:p))
  ##  range( cor(snp)[upper.tri(matrix( 0, ncol(snp), ncol(snp) ) )] )
  
  K <- p*ptrue
  ponly <- 1-pcross
  Swhole <- 1:floor(pcross*K)
  Sonly <- outer( 100*seq_len(M), (seq_len( ceiling(ponly*K)) ), "+" )
  wbeta <- as.matrix( cbind(matrix(replicate(nrow(Sonly), Swhole), nrow=nrow(Sonly), byrow=TRUE), Sonly)) 
  NameWhole <- paste0(Swhole, "(Whole)")
  if( pcross==1 ){
    NameOnly <- NA
  } else{ 
    NameOnly <- paste0(length(Swhole)+seq_len(ncol(Sonly)), "(Only)")
  }
  Colname_wbeta <- as.character( na.omit( c( NameWhole, NameOnly ) ) )
  dimnames(wbeta) <- list(paste0("Phenotype.",1:M), Colname_wbeta )
  beta <- matrix(0, nrow=p, ncol=M)
  for( m in 1:M ){
    beta[Swhole, m]    <- Beta*(--1)^(m+1)
    if( pcross != 1 ){
      beta[Sonly[m,], m] <- (--1)^(m)*(Beta-Beta.pdec*(sapply(Sonly[m,], digits, which=1)-1))
    }
  }
  
  ##  beta[1:10,1:m]
  ##  beta[101:110, 1:2]
  ##  beta[201:210, 1:2]
  ##  hist( MAF[as.numeric(wbeta)] )
  
  e.varcov <- GenVarcov(M, PropOfNeg = y.pNeg, Omega=Omega, rho=rho)
  e.varcov[upper.tri(e.varcov)] %>% sign %>% table
  y <- snp %*% beta + mnormt::rmnorm(n,varcov=e.varcov)
#  corrplot::corrplot(cor(y), tl.pos = "n")
  ValuesOfArguments = list(n=n, p=p, M=M, snp.rho=snp.rho, ptrue=ptrue, Beta=Beta, pcross=pcross,
                           y.pNeg=y.pNeg, Omega=Omega, rho.y = rho)
  return(list(snp=snp, y=y, MAF=MAF, beta=beta, wbeta=wbeta, e.varcov=e.varcov, args = ValuesOfArguments));
}
