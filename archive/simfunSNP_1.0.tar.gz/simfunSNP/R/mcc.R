mcc <- function(true, pred, p){
  data.frame(
    Actual = ifelse((1:p)%in% true, "TRUE", "FALSE"),
    Condition = ifelse((1:p)%in% pred, "+", "-") ) %>% table -> TABLE
  TP <- TABLE[2,2]
  FP <- TABLE[1,2]
  FN <- TABLE[2,1]
  TN <- TABLE[1,1]
  return( (TP*TN-FP*FN)/(sqrt(TP+FP)*sqrt(TP+FN)*sqrt(TN+FP)*sqrt(TN+FN)) );
}