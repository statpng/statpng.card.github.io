mglmnet.selprob <- function(SNP, Phenotype, idx=NULL, Alpha=NULL, nlambda=10, psub=0.5, K=100, cov=c("none","remainder","pc")){
  if( NCOL(Phenotype)>1 & is.null(idx) ) stop("Include an integer of idx")
  if( NCOL(Phenotype)==1 & !is.null(idx) ) stop("Include a data.frame or matrix of Phenotype")
  
  M <- ncol(Phenotype)
  
  n <- NROW(Phenotype);
  nsub <- n*psub;
  if(is.null(Alpha)) Alpha <- 1:9*0.1
  

  vector.lambda <- NULL
  for( i in 1:10 ){
    for( j in 1:length(Alpha) ){
      wsub <- sample(n, nsub)
      SNPsub <- SNP[wsub,]
      Phenotypesub <- Phenotype[wsub, ]
      fitsub <- mglmnet(x=SNPsub, y=Phenotypesub, idx=idx, alpha=Alpha[j], family="gaussian", cov=cov)
      vector.lambda <- c( vector.lambda, fitsub$lambda )
    }
  }
  
  lambda.min <- min(vector.lambda)
  lambda.max <- max(vector.lambda)
  
  seq.lambda <- seq(lambda.min, lambda.max, length.out=nlambda);
  out <- array(0, c(ncol(SNP), length(seq.lambda), length(Alpha)) );
  for( i in 1:K ){
    for( j in 1:length(Alpha) ){
      wsub <- sample(n, nsub);
      SNPsub <- SNP[wsub,];
      Phenotypesub <- Phenotype[wsub, ];
      mglmnet.fit <- mglmnet(x=SNPsub, y=Phenotypesub, idx=idx, family="gaussian", alpha=Alpha[j], lambda=seq.lambda, cov=cov)
      out[,,j] <- out[,,j] + as.numeric( mglmnet.fit$beta!=0 ) ;
    }
  }
  
  return(out);
  
}
