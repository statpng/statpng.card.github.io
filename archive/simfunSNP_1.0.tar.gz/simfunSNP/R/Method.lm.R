Method.lm <- function(SNP, Phenotype){
pvalue.lm <- sapply( 1:ncol(SNP), function(j) {
  fit_coef <- summary( lm( Phenotype ~ SNP[,j] ) )$coef
  ifelse( nrow(fit_coef)==2, fit_coef[2,4], 9999 )
} )
return(-log10(pvalue.lm))
}