mglmnet <- function(x=x, y=y, idx=NULL, cov=c("none", "remainder", "pc"), ...){
  yidx <- y[,idx]
  if(cov == "none"){
    return( glmnet(x=x, y=yidx, ...) )
  } else{
    if( NCOL(y)<2 ) stop("y should be a data.frame or matrix")
    if(is.null(idx)) stop("idx must be needed");
    yidx <- y[,idx]
    Remainder <- y[,-idx]
    if(cov == "remainder") {
      PF <- c( rep( 0, NCOL(Remainder) ), rep( 1, ncol(x) ) )
      out <- glmnet(x=cbind(Remainder, x), y=yidx, penalty.factor=PF, ...)
      out$dim[1] <- ncol(x)
      out$beta <- out$beta[-c(1:NCOL(Remainder)),]
      
      
      return( out )
    } else if(cov == "pc"){
      PC <- prcomp(Remainder, scale.=TRUE)
      PCcov <- PC$x[,which( summary( PC )$sdev > 1), drop=FALSE]
      PF <- c( rep( 0, NCOL(PCcov) ), rep( 1, ncol(x) ) )
      out <- glmnet(x=cbind(PCcov, x), y=yidx, penalty.factor=PF, ...)
      out$dim[1] <- ncol(x)
      out$beta <- out$beta[-c(1:NCOL(PCcov)),]
      return( out )
    }
  }
}
