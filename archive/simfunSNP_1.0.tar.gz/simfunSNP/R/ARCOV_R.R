ARCOV_R <- function(p, rho, threads=1) outer(1:p, 1:p, function(x,y) rho^abs(x-y) )
minmax <- function(x, lag){ 
  out <- ( x-min(x) )/(max(x)-min(x) )
  out 
}