glmnet_ycov <- function( SNP, Phenotype, idxY, Alpha, method ){
  
  Y <- Phenotype[,idxY]
  subY <- Phenotype[,-idxY]
  
  if( method == "glmnet" ){
    cvglmnet.fit <- cv.glmnet(SNP, Y, family="gaussian", alpha=Alpha, type.measure="mse" )
    glmnet.fit <- glmnet(SNP, Y, family="gaussian", alpha=Alpha, lambda=cvglmnet.fit$lambda.1se )
    return( which( glmnet.fit$beta != 0 ) );
    
  } else if( method == "ycov" ){
    X <- cbind(subY, SNP)
    cvglmnet.fit <- cv.glmnet(X, Y, family="gaussian", alpha=Alpha, type.measure="mse", penalty.factor = c( rep(0,ncol(subY)), rep(1,ncol(X)-ncol(subY)) ) ) 
    glmnet.fit <- glmnet(X, Y, family="gaussian", alpha=Alpha, lambda=cvglmnet.fit$lambda.1se, penalty.factor = c( rep(0,ncol(subY)), rep(1,ncol(X)-ncol(subY)) ) ) 
    return( which( glmnet.fit$beta != 0 ) );
    
  } else if( method == "pccov"){
    X <- cbind(SNP, Z <- prcomp(subY, scale=TRUE)$x[,1])
    cvglmnet.fit <- cv.glmnet(X, Y, family="gaussian", alpha=Alpha, type.measure="mse", penalty.factor=c(rep(0,1),rep(1,ncol(SNP))) ) 
    glmnet.fit <- glmnet(X, Y, family="gaussian", alpha=Alpha, lambda=cvglmnet.fit$lambda.1se, penalty.factor=c(rep(0,1),rep(1,ncol(SNP))) )
    return( which( glmnet.fit$beta != 0) );
    
  } else if( method == "lm" ){
    pvalue.lm <- sapply( 1:ncol(SNP), function(j) summary( lm( Y ~ SNP[,j] ) )$coef[2,4] )
    return( pvalue.lm );
  }
}